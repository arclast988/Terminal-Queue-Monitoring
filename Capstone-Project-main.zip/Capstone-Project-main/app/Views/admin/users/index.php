<?= $this->include('templates/header') ?>

<!-- Modern Frontend Styles -->
<link rel="stylesheet" href="<?= base_url('assets/css/modern-frontend.css') ?>">

<div class="page-header-modern fade-in">
    <h1 class="page-title-modern">
        <i class="bi bi-people-fill"></i>
        Manage Users
    </h1>
    <a href="<?= base_url('admin/users/create') ?>" class="btn-modern btn-modern-primary">
        <i class="bi bi-plus-circle"></i> Add New User
    </a>
</div>

<?php if (session()->getFlashdata('success')): ?>
    <div class="alert-modern alert-modern-success fade-in">
        <i class="bi bi-check-circle-fill alert-modern-icon"></i>
        <div><?= esc(session()->getFlashdata('success')) ?></div>
    </div>
<?php endif; ?>

<?php if (session()->getFlashdata('error')): ?>
    <div class="alert-modern alert-modern-danger fade-in">
        <i class="bi bi-exclamation-triangle-fill alert-modern-icon"></i>
        <div><?= esc(session()->getFlashdata('error')) ?></div>
    </div>
<?php endif; ?>

<?php
// Compute summary counts
$totalUsers = count($users);
$countAdmin = 0;
$countDispatcher = 0;
foreach ($users as $u) {
    if ($u['role'] === 'admin') {
        $countAdmin++;
    } else {
        $countDispatcher++;
    }
}
?>

<!-- User Search & Filter Bar -->
<div class="modern-card shadow-modern fade-in mb-4">
    <div class="modern-card-body">
        <div class="d-flex flex-wrap align-items-center gap-2 mb-3">
            <div class="input-group-modern me-3" style="max-width: 280px;">
                <span class="input-group-text bg-light border-end-0"><i class="bi bi-search"></i></span>
                <input type="text" class="input-modern border-start-0 ps-0" id="user-search" placeholder="Search name or username..." onkeyup="filterUsers(currentFilter)">
            </div>
            
            <span style="font-size:13px; font-weight:600; color:#64748b; text-transform:uppercase; letter-spacing:0.5px; margin-right:4px;">
                <i class="bi bi-funnel me-1"></i>Filter:
            </span>
            
            <button type="button" class="badge-modern badge-modern-primary active" id="filter-btn-all" onclick="filterUsers('all')">
                <i class="bi bi-grid-3x3-gap-fill"></i> All
                <span class="vf-count"><?= $totalUsers ?></span>
            </button>
            
            <span class="vf-divider" style="width:1px; height:24px; background:#dee2e6; margin:0 4px;"></span>
            
            <button type="button" class="badge-modern badge-modern-danger" id="filter-btn-admin" onclick="filterUsers('admin')">
                <i class="bi bi-shield-lock"></i> Admins
                <span class="vf-count"><?= $countAdmin ?></span>
            </button>
            
            <button type="button" class="badge-modern badge-modern-info" id="filter-btn-dispatcher" onclick="filterUsers('dispatcher')">
                <i class="bi bi-person-fill-gear"></i> Dispatchers
                <span class="vf-count"><?= $countDispatcher ?></span>
            </button>
        </div>
        
        <div id="filter-label" style="font-size:13px; color:#64748b;">Showing all <strong><?= $totalUsers ?></strong> users</div>
    </div>
</div>

<div class="modern-card shadow-modern fade-in">
    <div class="modern-card-header">
        <span class="modern-card-title">
            <i class="bi bi-people" style="color: var(--primary-red);"></i>
            User List
        </span>
    </div>
    <div class="modern-card-body">
        <div class="table-responsive">
            <table class="table-modern" id="users-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>User</th>
                        <th>Role</th>
                        <th>Assigned Routes</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $i => $user): ?>
                        <tr data-role="<?= esc($user['role']) ?>">
                            <td class="row-number" data-label="#"><?= $i + 1 ?></td>
                            <td data-label="User">
                                <?php
                                $nameParts = explode(' ', trim($user['full_name']));
                                $initials = '';
                                if (!empty($nameParts[0])) {
                                    $initials .= strtoupper(substr($nameParts[0], 0, 1));
                                }
                                if (count($nameParts) >= 2 && !empty($nameParts[count($nameParts) - 1])) {
                                    $initials .= strtoupper(substr($nameParts[count($nameParts) - 1], 0, 1));
                                }
                                if (empty($initials)) {
                                    $initials = strtoupper(substr($user['username'], 0, 2));
                                }
                                ?>
                                <div class="d-flex align-items-center">
                                    <div class="avatar-circle me-3 <?= $user['role'] === 'admin' ? 'avatar-admin' : 'avatar-dispatcher' ?>">
                                        <?= esc($initials) ?>
                                    </div>
                                    <div>
                                        <div class="fw-bold text-dark" style="font-size:14px;"><?= esc($user['full_name']) ?></div>
                                        <div>
                                            <small class="text-muted" style="font-size:11px;">@<?= esc($user['username']) ?></small>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td data-label="Role">
                                <span class="badge-modern badge-modern-<?= $user['role'] == 'admin' ? 'danger' : 'info' ?>">
                                    <?= $user['role'] == 'staff' ? 'Dispatcher' : ucfirst($user['role']) ?>
                                </span>
                            </td>
                            <td style="max-width: 350px;" data-label="Assigned Routes">
                                <?php if ($user['role'] === 'admin'): ?>
                                    <span class="badge-modern badge-modern-success">All Routes</span>
                                <?php elseif (!empty($user['assigned_routes_label']) && $user['assigned_routes_label'] !== 'None'): ?>
                                    <div class="badge-scroll-wrap" style="display: flex; gap: 4px; padding-bottom: 4px;" title="<?= esc($user['assigned_routes_label']) ?>">
                                        <?php
                                        $routeParts = explode(', ', $user['assigned_routes_label']);
                                        foreach ($routeParts as $rp):
                                            ?>
                                            <span class="badge-modern badge-modern-primary"
                                                style="font-size:10px; font-weight:500; white-space: nowrap;"><?= esc($rp) ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <span class="badge-modern badge-modern-warning">No Routes</span>
                                <?php endif; ?>
                            </td>
                            <td data-label="Action">
                                <div class="btn-group-modern" role="group">
                                    <a href="<?= base_url('admin/users/edit/' . $user['id']) ?>"
                                        class="btn-modern btn-modern-sm btn-modern-outline-primary" title="Edit">
                                        <i class="bi bi-pencil"></i> <span class="user-action-label">Edit</span>
                                    </a>
                                    <?php if ((int) $user['id'] !== (int) session()->get('id')): ?>
                                        <form action="<?= base_url('admin/users/delete/' . $user['id']) ?>" method="post"
                                            class="d-inline"
                                            onsubmit="return confirm('Delete user <?= esc($user['username']) ?>?')">
                                            <?= csrf_field() ?>
                                            <button type="submit" class="btn-modern btn-modern-sm btn-modern-outline-danger" title="Delete">
                                                <i class="bi bi-trash"></i> <span class="user-action-label">Delete</span>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
    #users-table {
        width: 100%;
    }

    #users-table th,
    #users-table td {
        vertical-align: middle;
    }

    /* Avatar Circles styling */
    .avatar-circle {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 13px;
        color: #fff;
        flex-shrink: 0;
        letter-spacing: 0.5px;
    }
    .avatar-admin {
        background: #dc2626;
        border: 2px solid rgba(220, 38, 38, 0.15);
    }
    .avatar-dispatcher {
        background: #0ea5e9;
        border: 2px solid rgba(14, 165, 233, 0.15);
    }

    .vf-count {
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        min-width: 22px !important;
        height: 22px !important;
        padding: 0 6px !important;
        border-radius: 12px !important;
        font-size: 11px !important;
        font-weight: 700 !important;
        background: rgba(255, 255, 255, 0.25) !important;
        color: #fff !important;
    }

    .user-row-hidden {
        display: none !important;
    }

    @media (max-width: 991.98px) {
        #users-table {
            font-size: 13px;
        }

        #users-table thead th,
        #users-table tbody td {
            padding: 0.65rem 0.5rem !important;
        }

        #users-table th:first-child,
        #users-table td.row-number {
            width: 38px;
            text-align: center;
        }

        .btn-group-modern {
            display: flex !important;
            gap: 0.35rem;
        }

        .btn-group-modern .btn-modern {
            width: 34px !important;
            height: 34px;
            padding: 0 !important;
            border-radius: 6px !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
        }

        .user-action-label {
            display: none;
        }
    }

    @media (max-width: 575.98px) {
        .vf-divider {
            display: none !important;
        }

        .badge-modern {
            flex: 1 1 calc(50% - 0.5rem);
            justify-content: center;
        }
    }
</style>

<script>
    let currentFilter = 'all';

    function filterUsers(filter) {
        currentFilter = filter;
        const rows = document.querySelectorAll('#users-table tbody tr[data-role]');
        const filterLabel = document.getElementById('filter-label');

        // Update active button styling
        document.querySelectorAll('.vf-btn').forEach(btn => btn.classList.remove('active'));
        const activeBtn = document.getElementById('filter-btn-' + filter);
        if (activeBtn) activeBtn.classList.add('active');

        // Filter label map
        const labelMap = {
            'all': 'all',
            'admin': 'Admin',
            'dispatcher': 'Dispatcher'
        };

        const searchQuery = document.getElementById('user-search') ? document.getElementById('user-search').value.toLowerCase() : '';

        let visibleCount = 0;
        rows.forEach(row => {
            let show = false;
            const role = row.getAttribute('data-role');
            if (filter === 'all') {
                show = true;
            } else if (filter === 'admin') {
                show = role === 'admin';
            } else if (filter === 'dispatcher') {
                show = role === 'staff';
            }

            if (show && searchQuery) {
                const textContent = row.textContent.toLowerCase();
                if (!textContent.includes(searchQuery)) {
                    show = false;
                }
            }

            if (show) {
                row.classList.remove('user-row-hidden');
                visibleCount++;
            } else {
                row.classList.add('user-row-hidden');
            }
        });

        // Re-number visible rows
        let num = 1;
        rows.forEach(row => {
            if (!row.classList.contains('user-row-hidden')) {
                const rowNumCell = row.querySelector('.row-number');
                if (rowNumCell) rowNumCell.textContent = num++;
            }
        });

        // Update filter label text
        if (filter === 'all') {
            filterLabel.innerHTML = 'Showing all <strong>' + visibleCount + '</strong> users';
        } else {
            filterLabel.innerHTML = 'Showing <strong>' + visibleCount + '</strong> ' + labelMap[filter] + ' user' + (visibleCount !== 1 ? 's' : '');
        }

        // Handle empty state
        let emptyRow = document.querySelector('#users-table .no-filter-results');
        if (visibleCount === 0 && rows.length > 0) {
            if (!emptyRow) {
                emptyRow = document.createElement('tr');
                emptyRow.classList.add('no-filter-results');
                emptyRow.innerHTML = '<td colspan="5" class="text-center py-4 text-muted"><i class="bi bi-inbox me-2"></i>No users match the selected filter.</td>';
                document.querySelector('#users-table tbody').appendChild(emptyRow);
            }
            emptyRow.style.display = '';
        } else if (emptyRow) {
            emptyRow.style.display = 'none';
        }
    }
</script>

<?= $this->include('templates/footer') ?>