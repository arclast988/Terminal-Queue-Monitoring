<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\RouteModel;
use App\Models\TerminalModel;
use App\Models\FareDiscountModel;
use App\Models\FareModel;

class Routes extends BaseController
{
    protected $routeModel;
    protected $terminalModel;
    protected $discountModel;

    public function __construct()
    {
        $this->routeModel    = new RouteModel();
        $this->terminalModel = new TerminalModel();
        $this->discountModel = new FareDiscountModel();
    }

    public function index()
    {
        helper('fare');

        $routes = $this->routeModel->select('routes.*, terminals.name as origin, terminals.name as terminal_name')
                                   ->join('terminals', 'terminals.id = routes.terminal_id')
                                   ->findAll();
        $routes = enrich_routes_with_discounts($routes);

        $data = [
            'title'  => 'Manage Routes',
            'routes' => $routes
        ];

        return view('admin/routes/index', $data);
    }

    /**
     * Get distinct destinations from the routes table for dropdown population.
     */
    private function getDistinctLocations(): array
    {
        $db = \Config\Database::connect();

        $destsResult   = $db->query('SELECT DISTINCT destination FROM routes ORDER BY destination ASC')->getResultArray();

        $destinations = array_column($destsResult, 'destination');
        $allLocations = array_unique($destinations);
        sort($allLocations);

        return [
            'origins'       => [],
            'destinations'  => $destinations,
            'all_locations' => $allLocations,
        ];
    }

    private function ensureRegularDiscount(int $terminalId): array
    {
        $regular = $this->discountModel
            ->where('terminal_id', $terminalId)
            ->where('type', 'regular')
            ->first();

        if ($regular) {
            return $regular;
        }

        $id = $this->discountModel->insert([
            'terminal_id'      => $terminalId,
            'type'             => 'regular',
            'label'            => 'Regular Fare',
            'discount_percent' => 0.00,
            'is_active'        => 1,
        ]);

        return $this->discountModel->find($id);
    }

    private function getDiscountsForFareCalculation(int $terminalId): array
    {
        $this->ensureRegularDiscount($terminalId);

        return $this->discountModel
            ->where('terminal_id', $terminalId)
            ->groupStart()
                ->where('type', 'regular')
                ->orWhere('is_active', 1)
            ->groupEnd()
            ->findAll();
    }

    private function replaceRouteFares(int $routeId, int $terminalId, float $baseFare): void
    {
        $fareModel = new FareModel();
        $fareModel->where('route_id', $routeId)->delete();

        foreach ($this->getDiscountsForFareCalculation($terminalId) as $discount) {
            $amount = ($discount['type'] === 'regular')
                ? $baseFare
                : round($baseFare * (1 - ((float) $discount['discount_percent'] / 100)), 2);

            $fareModel->insert([
                'route_id'         => $routeId,
                'fare_discount_id' => $discount['id'],
                'amount'           => $amount,
            ]);
        }
    }

    private function getRegularFare(int $routeId): float
    {
        $fareModel = new FareModel();
        $row = $fareModel
            ->select('fares.amount')
            ->join('fare_discounts', 'fare_discounts.id = fares.fare_discount_id')
            ->where('fares.route_id', $routeId)
            ->where('fare_discounts.type', 'regular')
            ->first();

        return $row ? (float) $row['amount'] : 0.00;
    }

    private function recalculateFaresForDiscount(array $discount): void
    {
        if ($discount['type'] === 'regular') {
            return;
        }

        $fareModel = new FareModel();
        $routes = $this->routeModel
            ->where('terminal_id', (int) $discount['terminal_id'])
            ->findAll();

        foreach ($routes as $route) {
            $baseFare = $this->getRegularFare((int) $route['id']);
            $amount = round($baseFare * (1 - ((float) $discount['discount_percent'] / 100)), 2);
            $existing = $fareModel
                ->where('route_id', $route['id'])
                ->where('fare_discount_id', $discount['id'])
                ->first();

            if ($existing) {
                $fareModel->update($existing['id'], ['amount' => $amount]);
                continue;
            }

            $fareModel->insert([
                'route_id'         => $route['id'],
                'fare_discount_id' => $discount['id'],
                'amount'           => $amount,
            ]);
        }
    }

    public function create()
    {
        $locations = $this->getDistinctLocations();

        $data = [
            'title'         => 'Add New Route',
            'terminals'     => $this->terminalModel->findAll(),
            'origins'       => $locations['origins'],
            'destinations'  => $locations['destinations'],
            'all_locations' => $locations['all_locations'],
        ];
        return view('admin/routes/create', $data);
    }

    public function store()
    {
        $rules = [
            'destination'  => 'required|min_length[2]|max_length[100]',
            'fare'         => 'required|decimal|greater_than[0]',
            'terminal_id'  => 'required|integer|is_not_unique[terminals.id]',
            'vehicle_type' => 'required|in_list[jeepney,van,minibus]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $terminalId  = $this->request->getPost('terminal_id');
        $terminal    = $this->terminalModel->find($terminalId);
        $origin      = strtoupper(trim($terminal['name'] ?? ''));
        $destination = strtoupper(trim($this->request->getPost('destination')));
        $vehicleType = $this->request->getPost('vehicle_type');
        $fare        = $this->request->getPost('fare');

        // Check for existing route with same terminal, destination, and vehicle type.
        $existing = $this->routeModel->where('terminal_id', $terminalId)
                                     ->where('destination', $destination)
                                     ->where('vehicle_type', $vehicleType)
                                     ->first();

        if ($existing) {
            return redirect()->back()->withInput()->with('error', "This route ($origin → $destination) already exists for " . ucfirst($vehicleType) . ". Please edit the existing one instead of adding a new one.");
        }

        $insertedId = $this->routeModel->insert([
            'destination'  => $destination,
            'terminal_id'  => $terminalId,
            'vehicle_type' => $vehicleType,
        ]);

        if (!$insertedId) {
            return redirect()->back()->withInput()->with('error', 'Failed to add route.');
        }

        $this->replaceRouteFares((int) $insertedId, (int) $terminalId, (float) $fare);

        $this->logActivity('Create route', "$origin → $destination ($vehicleType, ₱$fare).");

        return redirect()->back()->with('success', 'New route and fare added successfully.');
    }

    public function edit($id)
    {
        helper('fare');

        $route = $this->routeModel
            ->select('routes.*, terminals.name as origin')
            ->join('terminals', 'terminals.id = routes.terminal_id')
            ->find($id);

        if (!$route) {
            return redirect()->to('/admin/routes')->with('error', 'Route not found.');
        }

        $route = enrich_routes_with_discounts([$route])[0];

        $locations = $this->getDistinctLocations();

        $data = [
            'title'         => 'Edit Route',
            'route'         => $route,
            'terminals'     => $this->terminalModel->findAll(),
            'origins'       => $locations['origins'],
            'destinations'  => $locations['destinations'],
            'all_locations' => $locations['all_locations'],
        ];

        return view('admin/routes/edit', $data);
    }

    public function update($id)
    {
        $existingRoute = $this->routeModel
            ->select('routes.*, terminals.name as origin')
            ->join('terminals', 'terminals.id = routes.terminal_id')
            ->find($id);

        if (!$existingRoute) {
            return redirect()->to('/admin/routes')->with('error', 'Route not found.');
        }

        $rules = [
            'destination'  => 'required|min_length[2]|max_length[100]',
            'fare'         => 'required|decimal|greater_than[0]',
            'terminal_id'  => 'required|integer|is_not_unique[terminals.id]',
            'vehicle_type' => 'required|in_list[jeepney,van,minibus]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $terminalId  = $this->request->getPost('terminal_id');
        $terminal    = $this->terminalModel->find($terminalId);
        $origin      = strtoupper(trim($terminal['name'] ?? ''));
        $destination = strtoupper(trim($this->request->getPost('destination')));
        $vehicleType = $this->request->getPost('vehicle_type');
        $newFare     = $this->request->getPost('fare');
        $oldFare      = $this->getRegularFare((int) $id);
        if ($oldFare <= 0 && isset($existingRoute['fare'])) {
            $oldFare = (float) $existingRoute['fare'];
        }

        $collision = $this->routeModel->where('terminal_id', $terminalId)
                                      ->where('destination', $destination)
                                      ->where('vehicle_type', $vehicleType)
                                      ->where('id !=', $id)
                                      ->first();
        if ($collision) {
            return redirect()->back()->withInput()->with('error', "A route already exists for $origin → $destination ($vehicleType). Update that one instead.");
        }

        $updated = $this->routeModel->update($id, [
            'destination'  => $destination,
            'terminal_id'  => $this->request->getPost('terminal_id'),
            'vehicle_type' => $vehicleType,
        ]);

        if (!$updated) {
            return redirect()->back()->withInput()->with('error', 'Failed to update route.');
        }

        $this->replaceRouteFares((int) $id, (int) $terminalId, (float) $newFare);
        $newFareFloat = (float)$newFare;

        if (abs($oldFare - $newFareFloat) > 0.00001) {
            $this->logActivity(
                'Update fare',
                sprintf(
                    '%s route fare changed. Before: PHP %s | After: PHP %s.',
                    strtoupper($existingRoute['origin'] . ' to ' . $existingRoute['destination'] . ' (' . $existingRoute['vehicle_type'] . ')'),
                    number_format($oldFare, 2),
                    number_format($newFareFloat, 2)
                )
            );
        } else {
            $this->logActivity('Update route', $origin . ' to ' . $destination . ' (' . $vehicleType . ').');
        }

        return redirect()->back()->with('success', 'Route updated successfully.');
    }

    public function delete($id)
    {
        $route = $this->routeModel
            ->select('routes.*, terminals.name as origin')
            ->join('terminals', 'terminals.id = routes.terminal_id')
            ->find($id);
        if ($this->routeModel->delete($id)) {
            if ($route) {
                $this->logActivity('Delete route', $route['origin'] . ' → ' . $route['destination'] . '.');
            }
            return redirect()->back()->with('success', 'Route deleted successfully.');
        }
        return redirect()->back()->with('error', 'Failed to delete route.');
    }

    // ──────────────────────────────────────────────
    //  Discount Management
    // ──────────────────────────────────────────────

    /**
     * Update a discount record (percentage + label).
     */
    public function updateDiscount($id)
    {
        $discount = $this->discountModel->find($id);

        if (!$discount) {
            return redirect()->to('/fares')->with('error', 'Discount record not found.');
        }

        $rules = [
            'discount_percent' => 'required|decimal|greater_than_equal_to[0]|less_than_equal_to[100]',
            'label'            => 'required|min_length[2]|max_length[100]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->to('/fares')->with('errors', $this->validator->getErrors());
        }

        $updatedData = [
            'discount_percent' => $this->request->getPost('discount_percent'),
            'label'            => $this->request->getPost('label'),
            'is_active'        => $this->request->getPost('is_active') ? 1 : 0,
        ];

        $this->discountModel->update($id, $updatedData);
        $this->recalculateFaresForDiscount(array_merge($discount, $updatedData));

        $this->logActivity('Update discount', $discount['type'] . ' discount updated to ' . $this->request->getPost('discount_percent') . '%.');

        return redirect()->to('/fares')->with('success', 'Discount updated successfully.');
    }

    /**
     * Add a new discount type (for custom types beyond PWD/Senior/Student).
     */
    public function storeDiscount()
    {
        $rules = [
            'terminal_id'      => 'required|integer|is_not_unique[terminals.id]',
            'type'             => 'required|min_length[2]|max_length[50]|alpha_dash',
            'label'            => 'required|min_length[2]|max_length[100]',
            'discount_percent' => 'required|decimal|greater_than_equal_to[0]|less_than_equal_to[100]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->to('/fares')->with('errors', $this->validator->getErrors());
        }

        $type = strtolower(trim($this->request->getPost('type')));
        $terminalId = (int) $this->request->getPost('terminal_id');

        // Prevent duplicate types within the same terminal.
        $existing = $this->discountModel->where('terminal_id', $terminalId)->where('type', $type)->first();
        if ($existing) {
            return redirect()->to('/fares')->with('error', 'A discount with type "' . $type . '" already exists for this terminal. Please edit the existing one instead.');
        }

        $discountId = $this->discountModel->insert([
            'terminal_id'      => $terminalId,
            'type'             => $type,
            'label'            => $this->request->getPost('label'),
            'discount_percent' => $this->request->getPost('discount_percent'),
            'is_active'        => 1,
        ]);

        $discount = $this->discountModel->find($discountId);
        if ($discount) {
            $this->recalculateFaresForDiscount($discount);
        }

        $this->logActivity('Add discount', $this->request->getPost('label') . ' discount added at ' . $this->request->getPost('discount_percent') . '%.');

        return redirect()->to('/fares')->with('success', 'Discount added successfully.');
    }

    /**
     * Delete a discount record.
     */
    public function deleteDiscount($id)
    {
        $discount = $this->discountModel->find($id);

        if (!$discount) {
            return redirect()->to('/fares')->with('error', 'Discount record not found.');
        }

        if ($discount['type'] === 'regular') {
            return redirect()->to('/fares')->with('error', 'Regular fare cannot be deleted.');
        }

        $this->discountModel->delete($id);

        $this->logActivity('Delete discount', $discount['type'] . ' discount (' . $discount['label'] . ') deleted.');

        return redirect()->to('/fares')->with('success', 'Discount deleted successfully.');
    }
}
