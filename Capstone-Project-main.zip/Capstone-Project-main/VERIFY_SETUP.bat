@echo off
REM Verification script for Jeepney nVans setup (Windows WSL)
REM Run this after install_system.bat and start_system.bat to verify everything works

setlocal enableextensions
set "WSL_UTF8=1"
set "WSL=wsl -u root"

echo.
echo ======================================================================
echo   Jeepney nVans - Setup Verification (Windows WSL)
echo ======================================================================
echo.

REM Test WSL connectivity
%WSL% bash -c "echo '[OK] WSL is accessible'" || (
    echo [ERROR] Cannot communicate with WSL. Is WSL installed?
    pause
    exit /b 1
)

REM Get project path
for /f "usebackq delims=" %%p in (`%WSL% wslpath "%~dp0."`) do set "PROJECT_WSL=%%p"
echo [OK] Project path: %PROJECT_WSL%
echo.

REM Run Linux-side verification script
echo Running verification checks...
%WSL% bash -lc "sed 's/\r$//' '%PROJECT_WSL%/VERIFY_SETUP.sh' | bash"

echo.
echo ======================================================================
echo   Next steps:
echo   1. Open http://localhost/ in your browser
echo   2. Log in with your admin account
echo   3. Check the dashboard
echo ======================================================================
echo.
pause
